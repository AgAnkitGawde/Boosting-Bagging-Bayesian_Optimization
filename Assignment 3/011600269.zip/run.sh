#!/bin/sh
chmod +x Assignment3.py

python Assignment3.py >> output.txt

chmod +x run.sh
